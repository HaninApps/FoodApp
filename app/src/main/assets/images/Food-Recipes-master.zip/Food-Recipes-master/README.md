
 Food Recipes
=================

Members
------------

- Nguyen Hoang Phuc
- Nguyen Thanh Phong
- Nguyen Hoang Minh Phuc
- Le Nhat Phi

Descriptions
---------------
* Show to you details of Food and How to make it.
* We hope you enjoy it. Thank you so more!

Screenshots
-----------

![Trang chủ](Screenshots/home.PNG "A list of category")
![Xem món ăn](Screenshots/home2.PNG "Details for category")
![Chi tiết món ăn](Screenshots/detail.PNG "More about food")

Crew 15
-------

Copyright 2020 Crew 15 App Food Recipes.

Media Resources by: https://www.cooky.vn/

