package com.heno.haninArabic.myKitchen;

public class Category {

    private int _id;
    private String table;
    private String title;
    private String image;

    public int getId() {
        return _id;
    }

    public void setId(int _id) { this._id = _id;}



    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
